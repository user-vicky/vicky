Ultra Lab Final Setup
1. Extract ZIP
2. CMD:
   cd Desktop\UltraAdvancedLab_FINAL\backend
   npm install
   node server.js
3. Visit in browser:
   http://localhost:3000/test_form.html
   http://localhost:3000/patient_form.html