ULTRA LAB BRANDING PDF SETUP

1. Extract this ZIP on Desktop

2. Open CMD and run:
   cd Desktop\UltraLab_WithBranding\backend
   npm install
   node server.js

3. Open browser:
   http://localhost:3000/test_form.html

You can upload a JPG/PNG header image and generate PDF reports with that image at the top.
